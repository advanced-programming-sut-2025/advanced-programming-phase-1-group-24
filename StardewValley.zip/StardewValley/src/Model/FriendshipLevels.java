package Model;

public enum FriendshipLevels {
    stage0,
    stage1,
    stage2,
    stage3,
    stage4;

    public void useFriendship(){}
    //override later
}
