package Model.Animals;

public enum AnimalType{
    //Map of cage animal and barn animals
}
