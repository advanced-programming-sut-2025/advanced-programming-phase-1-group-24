package Model.Animals;

import Model.MapManagement.Tile;

public class Animal {
    AnimalType animalType;
    Tile currentTile;

    public AnimalType getAnimalType() {
        return animalType;
    }
}
