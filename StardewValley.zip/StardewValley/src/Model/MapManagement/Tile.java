package Model.MapManagement;

import Model.Growables.Growable;
import Model.Things.Item;

public class Tile {
    int x;
    int y;
    TileType type;
    boolean isWalkable;
    Item containedItem;
    Growable containedGrowable;

    public void changeTile(){}

}
