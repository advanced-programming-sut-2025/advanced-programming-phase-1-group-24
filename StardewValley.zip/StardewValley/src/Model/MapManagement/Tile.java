package Model.MapManagement;

import Model.Places.Place;

public class Tile {
    int x;
    int y;
    TileType type;
    Place place;

    public void changeTile(){}

}
