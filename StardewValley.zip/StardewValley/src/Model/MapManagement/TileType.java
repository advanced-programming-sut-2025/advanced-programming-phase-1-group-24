package Model.MapManagement;

public enum TileType {
    WATER,
    ROCK,
    GREENHOUSE,
    TREE;
}
