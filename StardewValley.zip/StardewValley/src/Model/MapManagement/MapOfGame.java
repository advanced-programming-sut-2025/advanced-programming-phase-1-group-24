package Model.MapManagement;

import Model.Things.ForagingType;

import java.util.ArrayList;

public class MapOfGame {

    ArrayList<Tile> map;

    public void changeTile(TileType newTile, TileType oldTile) {}

    public void randomForaging(ForagingType newForaging) {

    }
}
