package Model.Menus;

public enum TradeMenuController {
}
