package Model.Menus;

public enum LoginMenuCommands implements Commands {
}
