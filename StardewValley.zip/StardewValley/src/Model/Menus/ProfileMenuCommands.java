package Model.Menus;

public enum ProfileMenuCommands implements Commands {
}
