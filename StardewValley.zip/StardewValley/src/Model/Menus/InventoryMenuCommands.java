package Model.Menus;

public enum InventoryMenuCommands {
}
