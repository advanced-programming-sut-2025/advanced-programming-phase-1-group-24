package Model.Menus;

public interface Commands {
}
