package Model.Menus;

public enum StoreMenuCommands {
}
