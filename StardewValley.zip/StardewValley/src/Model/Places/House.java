package Model.Places;

import Model.Reccepies.Food;
import Model.Reccepies.Machine;

import java.util.ArrayList;

public class House extends Place{
    ArrayList<Food> fridge;
    ArrayList<Machine> machines;

    public ArrayList<Machine> getMachines() {
        return machines;
    }
}
