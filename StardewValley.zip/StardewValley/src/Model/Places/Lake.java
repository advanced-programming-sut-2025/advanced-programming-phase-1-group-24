package Model.Places;

public class Lake extends Place{

}
