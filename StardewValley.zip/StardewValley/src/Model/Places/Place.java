package Model.Places;

abstract public class Place {
    private int startX, startY;
    private int width, height;
}
