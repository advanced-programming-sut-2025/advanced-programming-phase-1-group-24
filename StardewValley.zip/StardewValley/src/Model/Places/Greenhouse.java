package Model.Places;

public class Greenhouse extends Place{

}
