package Model.Things;

public class Tool extends Item {
    ToolType type;
    int level;
    Material material;

    public ToolType getType() {
        return type;
    }
}
