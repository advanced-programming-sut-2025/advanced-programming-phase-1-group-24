package Model.Things;

public enum ItemType {
}
