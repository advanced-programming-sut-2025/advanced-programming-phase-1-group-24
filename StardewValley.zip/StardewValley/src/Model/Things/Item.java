package Model.Things;

public class Item {
    ItemType type;
}
