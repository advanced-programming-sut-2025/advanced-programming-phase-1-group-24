package Model.Things;

public enum ForagingType {
}
