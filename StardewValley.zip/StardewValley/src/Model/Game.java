package Model;

import Model.MapManagement.MapOfGame;
import Model.NPCManagement.NPC;
import Model.TimeManagement.TimeAndDate;
import Model.TimeManagement.WeatherType;

import java.util.ArrayList;

public class Game {
    MapOfGame map;
    ArrayList<User> users;
    TimeAndDate timeAndDate;

    WeatherType currentWeatherType;

    ArrayList<NPC> npcs;
    public void createNPC(){}

}
