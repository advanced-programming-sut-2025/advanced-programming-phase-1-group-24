package Model;

public enum Skill {
    fishingSkill,
    farmingSkill,
    miningSkill,
    foragingSkill;
}
