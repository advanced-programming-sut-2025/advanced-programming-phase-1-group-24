package Model.NPCManagement;

import Model.Result;
import Model.Things.Item;

import java.util.ArrayList;
import java.util.Map;

public class NPC{
    NPCnames npcName;
    ArrayList<Dialog> dialogs;

    Map<ArrayList<Item>, ArrayList<Item>> missions;
    //requiredItems, prizeItems

    public Result talkToNPC(){}
    public void doMission(){}
    public void giveGift(){}


}
