package Controller;

public class TradeMenuController {
}
