package Controller;

public class InventoryMenuController {
}
