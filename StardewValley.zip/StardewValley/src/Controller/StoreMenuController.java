package Controller;

public class StoreMenuController {
}
