package Controller;

import Model.Result;
import Model.Menus.GameMenuCommands;
import Model.Tools.ToolType;

public class GameMenuController {

    GameMenuCommands command;

    public Result createNewGame(String username1, String username2, String username3){}
    public Result pickGameMap(int mapNumber){}
    public Result loadGame(){}
    public Result exitGame(){}
    public Result removeGame(){}
    public Result nextTurn(){}
    public Result showTime(){}
    public Result showDate(){}
    public Result showTimeAndDate(){}
    public Result showDayOfWeek(){}
    public Result showSeason(){}
    public Result cheatAdvanceTime(int hours){}
    public Result cheatAdvanceDate(int days){}
    public void strikeRandomFarm(){}

    public void CheatStrikeLightening(){}

    public Result showCurrentWeather(){}
    public Result showPredictedWeather(){}
    public Result cheatSetWeather(){}
    public void buildGreenhouse(){}
    public Result walk(int x, int y){}
    public Result printMap(int x, int y, int size){}
    public Result helpReadMap(){}
    public Result showEnergy(){}
    public Result cheatEnergySet(int value){}
    public Result cheatEnergyUnlimited(){}
    public Result trashInventory(ToolType item, int quantity){}
    public Result showTradingMenu(){}


    public void startNewDay(){}

}
