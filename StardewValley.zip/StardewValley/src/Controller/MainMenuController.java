package Controller;

import Model.Menus.MainMenuCommands;

public class MainMenuController {
    MainMenuCommands command;


}
