package View;

import Controller.ProfileMenuController;
import Model.Result;

import java.util.Scanner;

public class ProfileMenu implements AppMenu{
    ProfileMenuController controller = new ProfileMenuController();

    public void check(Scanner scanner) {}
}
