package View;

import Controller.MainMenuController;
import Model.Result;

import java.util.Scanner;

public class MainMenu implements AppMenu{
    MainMenuController controller = new MainMenuController();


    public void check(Scanner scanner) {}
}
