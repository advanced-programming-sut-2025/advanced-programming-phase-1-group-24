package View;

import Controller.HouseMenuController;

import java.util.Scanner;

public class HouseMenu implements AppMenu {
    HouseMenuController controller = new HouseMenuController();
    public void check(Scanner scanner) {}
}
