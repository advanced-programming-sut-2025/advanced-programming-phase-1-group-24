import View.AppView;

public class Main {
    public static void main(String[] args) {
        (new AppView()).run();
    }
}