package Model.Menus;

public enum MainMenuCommands implements Commands {
}
