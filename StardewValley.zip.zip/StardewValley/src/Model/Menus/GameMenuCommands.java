package Model.Menus;

public enum GameMenuCommands implements Commands {
}
