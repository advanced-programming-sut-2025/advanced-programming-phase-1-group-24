package Model.MapManagement;

import Model.Places.Place;

public class Tile {
    int x;
    int y;
    TileType type;
    Place place;

    public void changeTile(){}

    public void useHoe(){}
    public void useAxe(){}
    public void usePickaxe(){}
    public void useWateringcan(){}
    public void useFishingPool(){}
    public void useScythe(){}
    public void useMilkPale(){}
    public void useShear(){}
}
