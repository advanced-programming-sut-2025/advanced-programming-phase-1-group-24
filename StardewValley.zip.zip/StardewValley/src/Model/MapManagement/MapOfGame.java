package Model.MapManagement;

import java.util.ArrayList;

public class MapOfGame {

    ArrayList<Tile> map;

    public void changeTile(TileType newTile, TileType oldTile) {}

    public void randomForaging(){}
}
