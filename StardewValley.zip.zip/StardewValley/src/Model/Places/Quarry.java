package Model.Places;

public class Quarry extends Place {

}
