package Model.Places;

import Model.Things.Item;

import java.util.ArrayList;

public class Shop extends Place{
    ShopType shopType;
    ArrayList<Item> products;

}
