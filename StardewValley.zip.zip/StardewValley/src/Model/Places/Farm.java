package Model.Places;

public class Farm extends Place {

}
