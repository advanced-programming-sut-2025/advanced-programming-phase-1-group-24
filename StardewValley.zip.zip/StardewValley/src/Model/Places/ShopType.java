package Model.Places;

public enum ShopType {
}
