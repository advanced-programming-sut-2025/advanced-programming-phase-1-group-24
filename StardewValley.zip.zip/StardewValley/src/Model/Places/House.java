package Model.Places;

import Model.Things.MachineTypes;

import java.util.ArrayList;

public class House extends Place{
  ArrayList<MachineTypes> machines;

    public ArrayList<MachineTypes> getMachines() {
        return machines;
    }
}
