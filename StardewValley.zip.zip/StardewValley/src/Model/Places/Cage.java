package Model.Places;

import Model.Animals.Animal;

import java.util.ArrayList;

public class Cage extends Place{
    ArrayList<Animal> animals = new ArrayList<>();
}
