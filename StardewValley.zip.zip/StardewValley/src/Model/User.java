package Model;

import Model.MapManagement.Tile;
import Model.Places.Shop;
import Model.Things.Backpack;
import Model.Things.Item;
import Model.Things.Trashcan;
import Model.Things.ToolType;

import java.util.*;

public class User {
    String username;
    String password;
    String nickname;
    String email;
    int energy = 200;
    int fishingSkill;
    int farmingSkill;
    int miningSkill;
    int foragingSkill;
    Tile currentTile;
    ToolType currentTool;
    Shop currentShop;
    ArrayList<String> craftingRecepies;
    ArrayList<String> cookingRecepies;
    Map<User, Map<ArrayList<Item>, ArrayList<Item>>> tradeHistory;
    Map<User, FriendshipLevels> friends;
    Backpack backpack;
    Trashcan trashCan;


    public User(String username, String password, String nickname, String email) {
        this.username = username;
        this.password = password;
        this.nickname = nickname;
        this.email = email;
    }

    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getNickname() { return nickname; }
    public String getEmail() { return email; }

    public int getEnergy() {
        return energy;
    }

    public int getFarmingSkill() {
        return farmingSkill;
    }

    public int getFishingSkill() {
        return fishingSkill;
    }

    public ArrayList<String> getCookingRecepies() {
        return cookingRecepies;
    }

    public ArrayList<String> getCraftingRecepies() {
        return craftingRecepies;
    }

    public int getForagingSkill() {
        return foragingSkill;
    }

    public int getMiningSkill() {
        return miningSkill;
    }

    public Map<User, Map<ArrayList<Item>, ArrayList<Item>>> getTradeHistory() {
        return tradeHistory;
    }

    public Map<User, FriendshipLevels> getFriends() {
        return friends;
    }

    public Shop getCurrentShop() {
        return currentShop;
    }

    public Tile getCurrentTile() {
        return currentTile;
    }

    public ToolType getCurrentTool() {
        return currentTool;
    }

    public void setUsername(String username) { this.username = username; }
    public void setPassword(String password) { this.password = password; }
    public void setNickname(String nickname) { this.nickname = nickname; }
    public void setEmail(String email) { this.email = email; }

    public void faint(){};
    public void setEnergy(int energy) { this.energy = energy; }

    public void trade(){}

}
