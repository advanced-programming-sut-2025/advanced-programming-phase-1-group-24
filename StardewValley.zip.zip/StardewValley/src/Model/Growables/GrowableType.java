package Model.Growables;

public enum GrowableType {
    Tree {
        TreeType type;
    },
    Plant{
        PlantType type;
    };
}
