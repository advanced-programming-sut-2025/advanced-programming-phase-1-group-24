package Model.Things;

public class Trashcan {
    TrashCanType type;

    public TrashCanType getType() {
        return type;
    }
}
