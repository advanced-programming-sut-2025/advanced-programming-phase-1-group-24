package Model.Things;

public enum ToolType {
    HOE(),
    PICKAXE,
    AXE,
    WATERINGCAN,
    FISHINGPOLE,
    SCYTHE,
    MILKPAIL,
    SHEAR,
    BACKPACK,
    TRASHCAN;


    int price;
    int level;

    public void breakTool(){}

}
