package Model.Things;

public class Tool extends Item {
    ToolType type;

    public ToolType getType() {
        return type;
    }
}
