package Model.Things;

public enum TrashCanType {
    INITIAL(0),
    COPPER(15),
    IRON(30),
    GOLD(45),
    IREDIOM(60);

    int percentage;

    TrashCanType(int percentage) {
        this.percentage = percentage;
    }

    public int getPercentage() {
        return percentage;
    }

    public void useTrashcan(){}  //gets Overriden later
}
