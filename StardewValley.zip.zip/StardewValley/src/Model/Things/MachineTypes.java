package Model.Things;

public enum MachineTypes {

    public void useMachine(){} //overridden later
}
