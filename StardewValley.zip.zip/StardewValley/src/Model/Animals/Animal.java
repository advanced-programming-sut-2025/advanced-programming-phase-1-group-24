package Model.Animals;

public class Animal {
    AnimalType animalType;

    public AnimalType getAnimalType() {
        return animalType;
    }
}
