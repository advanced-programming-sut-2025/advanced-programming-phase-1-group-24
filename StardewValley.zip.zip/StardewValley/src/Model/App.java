package Model;

import Model.Menus.Menu;

import java.util.ArrayList;

public class App {
    private static App instance;
    private ArrayList<Game> games = new ArrayList<>();

    private Menu currentMenu;

    public Menu getCurrentMenu() {
        return currentMenu;
    }

    public ArrayList<Game> getGames() {
        return games;
    }

    private App(){};

    public static App getInstance(){
        if(instance == null){
            instance = new App();
        }
        return instance;
    }

    private ArrayList<User> users = new ArrayList<>();

    private User loggedInUser;
}
