package View;

import Controller.GameMenuController;
import Model.Result;

import java.util.Scanner;

public class GameMenu implements AppMenu {
    GameMenuController controller = new GameMenuController();
    public void check(Scanner scanner) {}

}
