package org.example.Model.Places;

public enum ShopItemType {
    ANIMAL,
    TRASHCAN,
    FISH,
    Source,
    //TOOLS
    AXE,
    HOE,
    MILKPAIL,
    PICKAXE,
    SHEAR,
    SCYTHE,
    FISHINGPOLE,
    WTERINGCAN,


    FOOD,
    FOODRECIPE,

    BARN,
    CAGE,

    RANDOMSTUFF,
    HAY,

    MACHINERECIPE,

    LARGE_BACKPACK,
    DELUXE_BACKPACK,

    SHIPPING_BIN,
FORAGINGMINERAL,
    TOOL_UPGRADE,




}
