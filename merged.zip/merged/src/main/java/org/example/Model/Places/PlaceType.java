package org.example.Model.Places;

public enum PlaceType {
    Cage,
    Farm,
    House,
    GreenHouse,
    Lake,
    Quarry,
    Shop;
}
