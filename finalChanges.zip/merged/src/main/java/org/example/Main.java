package org.example;


import org.example.View.AppView;

public class Main {
    // test
    public static void main(String[] args) {
        (new AppView()).run();
    }
}