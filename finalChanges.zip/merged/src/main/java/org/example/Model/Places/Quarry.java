package org.example.Model.Places;

public class Quarry extends Place{
    public Quarry(int startX, int startY, int width, int height){
        this.x = startX;
        this.y = startY;
        this.width = width;
        this.height = height;
    }
    
}
