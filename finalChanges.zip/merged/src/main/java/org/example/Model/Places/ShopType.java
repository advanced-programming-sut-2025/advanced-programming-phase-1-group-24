package org.example.Model.Places;

public enum ShopType {
    BLACKSMITH,
    JOJA_MART,
    PIERRE_GENERAL_SHOP,
    PIERRE_STORE,
    CARPENTER_SHOP,
    FISH_SHOP,
    MARNIE_RANCH,
    STAR_DROP_SALOON
}