package org.example.Model.Things;

public abstract class Item {
    public String name;
    public boolean isSellable;
    public int price;
    public boolean isPlacable;
    public boolean isTool;
}
