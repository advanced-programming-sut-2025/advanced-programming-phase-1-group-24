package org.example.Model.Menus;

public enum GameMenuCommands implements Commands {
    //inventory commands
    SHOW_INVENTORY("^\\s*inventory\\s+show\\s*$"),
    INVENTORY_TRASH("^\\s*inventory\\s+trash\\s+-i\\s+(?<item name>.+?)(?:\\s+-n\\s+(?<number>\\d+))?$"),
    EQUIP_TOOL("^\\s*tools\\s+equip\\s+(?<tool_name>.+)\\s*$"),
    SHOW_CURRENT_TOOL("^\\s*tools\\s+show\\s+current\\s*$"),
    SHOW_AVAILABLE_TOOLS("^\\s*tools\\s+show\\s+available\\s*$");
}
