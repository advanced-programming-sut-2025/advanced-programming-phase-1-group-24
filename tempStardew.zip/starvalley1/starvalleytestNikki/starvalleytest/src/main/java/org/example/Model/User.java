package org.example.Model;

import org.example.Model.MapManagement.Tile;
import org.example.Model.Reccepies.Craft;
import org.example.Model.Reccepies.FoodRecipe;
import org.example.Model.Things.Food;
import org.example.Model.Things.Backpack;
import org.example.Model.Things.Item;
import org.example.Model.Tools.Tool;
import org.example.Model.Tools.ToolType;

import java.util.ArrayList;
import java.util.Map;

public class User {
    String username;
    String password;
    String nickname;
    String email;
    boolean gender;
    int energy = 200;
    Map<Skill, Integer> skills;
    Tile currentTile;
    Tool equippedTool;
    ArrayList<Craft> craftingRecepies;
    ArrayList<FoodRecipe> cookingRecepies;
    Map<User, Map<ArrayList<Item>, ArrayList<Item>>> tradeHistory;
    Map<User, FriendshipLevels> friends;
    Backpack backpack;
    Tool trashCan;


    public User(String username, String password, String nickname, String email, boolean gender) {
        this.username = username;
        this.password = password;
        this.nickname = nickname;
        this.email = email;
        this.gender = gender;
        this.equippedTool = null;
    }

    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getNickname() { return nickname; }
    public String getEmail() { return email; }

    public int getEnergy() {
        return energy;
    }

    public ArrayList<FoodRecipe> getCookingRecepies() {
        return cookingRecepies;
    }

    public Map<User, Map<ArrayList<Item>, ArrayList<Item>>> getTradeHistory() {
        return tradeHistory;
    }

    public Map<User, FriendshipLevels> getFriends() {
        return friends;
    }

    public Tile getCurrentTile() {
        return currentTile;
    }

    public Tool getEquippedTool() {
        return equippedTool;
    }
    public void setEquippedTool(Tool equippedTool) { this.equippedTool = equippedTool; }

    public void setUsername(String username) { this.username = username; }
    public void setPassword(String password) { this.password = password; }
    public void setNickname(String nickname) { this.nickname = nickname; }
    public void setEmail(String email) { this.email = email; }

    public void faint(){};
    public void setEnergy(int energy) { this.energy = energy; }

    public void trade(){}

}
