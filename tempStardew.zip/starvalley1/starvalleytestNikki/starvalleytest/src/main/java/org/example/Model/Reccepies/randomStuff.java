package org.example.Model.Reccepies;

public enum randomStuff {
    Pumpkin,
    WheatFlower,
    Sugar,
    Cheese,
    Rice,
    Fiber,
    Coffee,
    Oil,
}
