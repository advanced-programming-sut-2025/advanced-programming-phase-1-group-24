package org.example.View;

import Controller.InventoryMenuController;

import java.util.Scanner;

public class InventoryMenu {
    InventoryMenuController controller = new InventoryMenuController();
    public void check(Scanner scanner) {}
}
