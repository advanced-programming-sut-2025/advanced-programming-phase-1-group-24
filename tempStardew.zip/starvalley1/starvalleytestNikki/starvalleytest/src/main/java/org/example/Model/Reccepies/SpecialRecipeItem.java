package org.example.Model.Reccepies;

public enum SpecialRecipeItem {
    AnyFish,
}
