package org.example.Model.Things;

import org.example.Model.Result;
import org.example.Model.Tools.Tool;

import java.util.HashMap;
import java.util.Map;

public class Backpack {
    BackpackType type;
    private int maxSize;
    Map<Item, Integer> inventoryItems;

    public BackpackType getType() {
        return type;
    }

    public Backpack(){
        this.type = BackpackType.INITIAL;
        this.maxSize = type.getCapacity();
        this.inventoryItems = new HashMap<Item, Integer>();
    }

    public void upgrade(BackpackType type) {
        this.type = type;
        this.maxSize = type.getCapacity();
    }

    public Result addItem(Item item, int amount) {
        if (inventoryItems.size() >= maxSize) {
            return new Result(false,"inventory is full");
        }
        else if (inventoryItems.containsKey(item)) {
            inventoryItems.put(item, inventoryItems.get(item) + amount);
        }
        else {
            inventoryItems.put(item, amount);
        }
        return new Result(true,"item added");
    }

    public Result removeItem(Item item, int amount) {
        if (inventoryItems.containsKey(item)) {
            inventoryItems.put(item, inventoryItems.get(item) - amount);
            if (inventoryItems.get(item) <= 0) {}
        }
    }

    public Result equipTool(Tool tool) {
        for (Item item : inventoryItems.keySet()) {
            if (item instanceof Tool) {
                Tool existingTool = (Tool) item;
                if (existingTool.getType().equals(tool.getType())) {
                    App.getinstance.GetCurrentGame.getCurrentPlayer.currentUser.setEquippedTool(tool);
                    return new Result(true,"equipped tool successfully");
                }
            }
        }
        return new Result(false,"tool not found");
    }



    

}
