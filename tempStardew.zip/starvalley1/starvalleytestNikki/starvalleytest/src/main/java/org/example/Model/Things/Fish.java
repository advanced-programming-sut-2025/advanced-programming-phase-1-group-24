package org.example.Model.Things;

public class Fish extends Item{
    FishType type;
}
