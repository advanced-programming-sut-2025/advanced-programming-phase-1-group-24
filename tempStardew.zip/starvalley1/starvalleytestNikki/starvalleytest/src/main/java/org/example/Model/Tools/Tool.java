package org.example.Model.Tools;

import org.example.Model.Things.Item;
import org.example.Model.Things.ToolMaterial;

public class Tool extends Item {
    ToolType type;
    int level;
    ToolMaterial material;

    public ToolType getType() {
        return type;
    }
}
