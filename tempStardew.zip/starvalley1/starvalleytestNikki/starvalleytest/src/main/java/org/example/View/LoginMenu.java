package org.example.View;

import Controller.LoginMenuController;

import java.util.Scanner;

public class LoginMenu implements AppMenu{
    LoginMenuController controller = new LoginMenuController();
    public void check(Scanner scanner) {}
}
