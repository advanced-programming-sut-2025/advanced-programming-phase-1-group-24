package org.example.Controller;

public class StoreMenuController {
}
