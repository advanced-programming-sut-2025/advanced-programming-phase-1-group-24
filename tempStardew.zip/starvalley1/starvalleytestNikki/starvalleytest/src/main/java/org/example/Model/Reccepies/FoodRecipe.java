package org.example.Model.Reccepies;

import org.example.Model.Growables.CropType;
import org.example.Model.Growables.GrowableType;
import org.example.Model.Things.FishType;
import org.example.Model.Things.FoodType;
import org.example.Model.Things.Item;

import java.util.ArrayList;
import java.util.Map;

public enum FoodRecipe {
    FriedEgg(Map.of(AnimalProduct.Egg, 1),50,35),
    BakedFish(Map.of(
            FishType.Sardine, 1,
            FishType.Salmon, 1,
            CropType.Wheat, 1),75,100),
    Salad(Map.of(ForaginCropType.Leek,1,
                ForagingCropType.Dandelion,1),113,110),
    Omelet(Map.of(AnimalProduct.Egg,1,
                  AnimalProduct.Milk,1),100,125),
    PumpkinPie(Map.of(randomStuff.Pumpkin,1,
            randomStuff.WheatFlower,1,
            AnimalProduct.Milk,1,
            randomStuff.Sugar,1),225,385),
    Spaghetti(Map.of(randomStuff.WheatFlower,1,
            CropType.Tomato,1),75,120),
    Pizza(Map.of(randomStuff.WheatFlower,1,
            CropType.Tomato,1,
            randomStuff.Cheese,1),150,300),
    Tortilla(Map.of(CropType.Corn,1),50,50),
    MakiRoll(Map.of(SpecialRecipeItem.AnyFish,1,
            randomStuff.Rice,1,
            randomStuff.Fiber,1),100,220),
    TripleShotEspresso(Map.of(randomStuff.Coffee,3),200,450),
    Cookie(Map.of(randomStuff.WheatFlower,1,
            AnimalProduct.Egg,1,
            randomStuff.Sugar,1),90,140),
    HashBrowns(Map.of(CropType.Potato,1,
            randomStuff.Oil,1),90,120),
    Pancakes(Map.of(randomStuff.WheatFlower,1,
            AnimalProduct.Egg,1),90,80),
    FruitSalad(Map.of(CropType.Blueberry,1,
            CropType.Melon,1,
            FruitType.Apricot,1),263,450),
    RedPlate(Map.of(CropType.RedCabbage,1,
            CropType.Radish,1),240,400),
    Bread(Map.of(randomStuff.WheatFlower,1),50,60),
    SalmonDinner(Map.of(FishType.Salmon,1,
            CropType.Amaranth,1,
            CropType.Kale,1),125,300),
    VegetableMedley(Map.of(CropType.Tomato,1,
            CropType.Beet,1),165,120),
    FarmersLaunch(Map.of(FoodType.Omelet,1,
            CropType.Parsnip,1),200,150),
    SurvivalBurger(Map.of(FoodType.Bread,1,
            CropType.Eggplant,1,
            CropType.Carrot,1),125,180),
    DishOtheSea(Map.of(FishType.Sardine,2,
            FoodType.HashBrown,1),150,220),
    SeaformPudding(Map.of(FishType.Flounder,1,
            FishType.Midnight_Carp,1),175,300),
    MinersTreat(Map.of(CropType.Carrot,2,
            randomStuff.Sugar,1,
            AnimalProduct.Milk,1),125,200);



    private final Map<Enum<?>, Integer> recipe;
    private int energy;
    private int sellPrice;

    FoodRecipe(Map<Enum<?>, Integer> recipe, int energy, int sellPrice) {
        this.recipe = recipe;
        this.energy = energy;
        this.sellPrice = sellPrice;
    }

    public Map<Enum<?>, Integer> getRecipe() {
        return recipe;
    }
    public int getEnergy() {return energy;}
    public int getSellPrice() {return sellPrice;}
}