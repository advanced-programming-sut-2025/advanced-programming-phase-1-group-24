package org.example.Model.Places;

public enum ShopType {
}
