package org.example.Model.Things;

public enum ToolMaterial {
    Initial,
    Iron,
    Gold,
    Copper,
    Iridium;
}
