package org.example.Model.Things;

import org.example.Model.Growables.CropType;
import org.example.Model.Reccepies.FoodRecipe;
import org.example.Model.Reccepies.SpecialRecipeItem;
import org.example.Model.Reccepies.randomStuff;

import java.util.Map;

public enum FoodType {
    FriedEgg,
    BakedFish,
    Salad,
    Omelet,
    PumpkinPie,
    Spaghetti,
    Pizza,
    Tortilla,
    MakiRoll,
    TripleShotEspresso,
    Cookie,
    HashBrowns,
    Pancakes,
    FruitSalad,
    RedPlate,
    Bread,
    SalmonDinner,
    VegetableMedley,
    FarmersLaunch,
    SurvivalBurger,
    DishOtheSea,
    SeaformPudding,
    MinersTreat;

    FoodRecipe recipe;

    public FoodRecipe getRecipe() { return recipe; }


}
