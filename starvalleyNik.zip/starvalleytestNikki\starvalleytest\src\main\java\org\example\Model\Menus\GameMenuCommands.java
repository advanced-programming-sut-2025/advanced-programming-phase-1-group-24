package org.example.Model.Menus;

public enum GameMenuCommands implements Commands {
}
