package org.example.Model.Growables;

public class Growable {
    Seeds seeds;
    GrowableType growableType;

    public Seeds getSeeds() {
        return seeds;
    }

    public void grow(){}
    public void harvest(){}
}
