package org.example.Model.Places;

import java.util.*;
import org.example.Model.MapManagement.Tile;


abstract public class Place {
    //protected int width, height;
    protected ArrayList<Tile> tiles = new ArrayList<>();

    public ArrayList<Tile> getTiles() {
        return tiles;
    }

    public void setTiles(ArrayList<Tile> tiles) {
        this.tiles = tiles;
    }
}

