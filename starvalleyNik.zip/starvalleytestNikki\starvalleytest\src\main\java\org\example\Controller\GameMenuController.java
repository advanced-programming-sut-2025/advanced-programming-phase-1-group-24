package org.example.Controller;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

import org.example.Model.*;
import org.example.Model.MapManagement.Tile;
import org.example.Model.Tools.ToolType;

public class GameMenuController {

    //GameMenuCommands command;

    public Result createNewGame(String username1, String username2, String username3){
        //load farm.json
        //create a new game and put it as currentgame in app
        //for the newely created game create a map and initialize it with the function initializeMap that exists in MapOfGame class
        
    }

    //we will call this method for every user 
    public void pickGameMap(int mapNumber){
        App app = App.getInstance();
        Game currentGame = app.getCurrentGame();
        if(mapNumber % 2 == 0){
           
        }

    }
    public Result loadGame(){}
    public Result exitGame(){}
    public Result removeGame(){}
    public Result nextTurn(){}
    public Result showTime(){}
    public Result showDate(){}
    public Result showTimeAndDate(){}
    public Result showDayOfWeek(){}
    public Result showSeason(){}
    public Result cheatAdvanceTime(int hours){}
    public Result cheatAdvanceDate(int days){}
    public void strikeRandomFarm(){}

    public void CheatStrikeLightening(){}

    public Result showCurrentWeather(){}
    public Result showPredictedWeather(){}
    public Result cheatSetWeather(){}
    public void buildGreenhouse(){}
    public Result walk(int x, int y){}
    public Result printMap(int x, int y, int size){}
    public Result helpReadMap(){}
    public Result showEnergy(){}
    public Result cheatEnergySet(int value){}
    public Result cheatEnergyUnlimited(){}
    public Result trashInventory(ToolType item, int quantity){}
    public Result showTradingMenu(){}


    public void startNewDay(){}


    public List<Farm> loadFarmTemplates() {
    Gson gson = new Gson();
    try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream("farm.json")) {
        if (inputStream == null) {
            throw new RuntimeException("farm.json not found in resources.");
        }

        InputStreamReader reader = new InputStreamReader(inputStream);
        Type listType = new TypeToken<List<FarmTemplate>>() {}.getType();
        return gson.fromJson(reader, listType);

    } catch (Exception e) {
            e.printStackTrace();
            return null;
    }
    }


    public static boolean isCornerAvailable(Tile[][] map, int startX, int startY, int width, int height) {
    for (int y = startY; y < startY + height; y++) {
        for (int x = startX; x < startX + width; x++) {
            if (x >= map[0].length || y >= map.length || map[y][x].getType() != null)
                return false;
        }
    }
        return true;
    }


}
