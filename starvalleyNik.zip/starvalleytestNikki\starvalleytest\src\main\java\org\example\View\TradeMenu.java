package org.example.View;

import Controller.TradeMenuController;

import java.util.Scanner;

public class TradeMenu implements AppMenu {
    TradeMenuController controller = new TradeMenuController();
    public void check(Scanner scanner) {}
}
