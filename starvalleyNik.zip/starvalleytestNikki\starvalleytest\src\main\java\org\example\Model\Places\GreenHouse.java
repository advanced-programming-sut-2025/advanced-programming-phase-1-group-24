package org.example.Model.Places;

public class GreenHouse extends Place{
    private boolean isGreenHouseFixed = false;

    public GreenHouse(){
        

    }

    public boolean getIsGreenHouseFixed(){
        return isGreenHouseFixed;
    }



    
}
