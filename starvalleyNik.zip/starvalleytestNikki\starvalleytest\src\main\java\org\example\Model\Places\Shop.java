package org.example.Model.Places;

import java.util.ArrayList;

import org.example.Model.Things.Item;

public class Shop extends Place{
    ShopType shopType;
    ArrayList<Item> products;
    
}
