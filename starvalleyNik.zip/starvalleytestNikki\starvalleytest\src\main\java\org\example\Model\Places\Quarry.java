package org.example.Model.Places;

public class Quarry extends Place{
    
}
