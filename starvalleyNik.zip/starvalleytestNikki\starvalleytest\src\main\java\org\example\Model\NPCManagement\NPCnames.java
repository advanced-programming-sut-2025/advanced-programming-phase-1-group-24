package org.example.Model.NPCManagement;

public enum NPCnames {
}
