package org.example.Model.Places;

import java.util.ArrayList;

import org.example.Model.User;

public class Farm extends Place{
    private ArrayList<Habitat> cage;
    private ArrayList<Habitat> barn;
    private ArrayList<Habitat> lake;
    private GreenHouse greenHouse;
    private Quarry quarry;
    private House house;
    private User owner;


    public Farm(User owner){
        this.owner = owner;
    }


    public ArrayList<Habitat> getCage() {
        return cage;
    }
    public ArrayList<Habitat> getBarn() {
        return barn;
    }
    public ArrayList<Habitat> getLake() {
        return lake;
    }
    public GreenHouse getGreenHouse() {
        return greenHouse;
    }
    public Quarry getQuarry() {
        return quarry;
    }
    public House getHouse() {
        return house;
    }
    public User getOwner() {
        return owner;
    }


    public void setLake(ArrayList<Habitat> lake) {
        this.lake = lake;
    }
    public void setCage(ArrayList<Habitat> cage) {
        this.cage = cage;
    }
    public void setBarn(ArrayList<Habitat> barn) {
        this.barn = barn;
    }
    public void setGreenHouse(GreenHouse greenHouse) {
        this.greenHouse = greenHouse;
    }
    public void setQuarry(Quarry quarry) {
        this.quarry = quarry;
    }
    public void setHouse(House house) {
        this.house = house;
    }
    public void setOwner(User owner) {
        this.owner = owner;
    }
    
}
