package org.example.View;

import Controller.ProfileMenuController;

import java.util.Scanner;

public class ProfileMenu implements AppMenu{
    ProfileMenuController controller = new ProfileMenuController();

    public void check(Scanner scanner) {}
}
