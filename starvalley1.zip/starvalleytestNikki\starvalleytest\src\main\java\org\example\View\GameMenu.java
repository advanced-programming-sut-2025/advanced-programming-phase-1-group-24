package org.example.View;

import Controller.GameMenuController;

import java.util.Scanner;

public class GameMenu implements AppMenu {
    GameMenuController controller = new GameMenuController();
    public void check(Scanner scanner) {}

}
