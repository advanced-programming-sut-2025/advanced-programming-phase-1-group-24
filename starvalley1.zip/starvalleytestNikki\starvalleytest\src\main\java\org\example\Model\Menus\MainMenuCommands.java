package org.example.Model.Menus;

public enum MainMenuCommands implements Commands {
}
