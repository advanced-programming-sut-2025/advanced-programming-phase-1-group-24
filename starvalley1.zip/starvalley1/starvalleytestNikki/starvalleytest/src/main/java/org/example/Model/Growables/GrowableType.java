package org.example.Model.Growables;

public enum GrowableType {
    Tree,
    ForagingTree,
    Source,
    ForagingSeed,
    Fruit,
    ForagingCrop,   //put the object of foraging crop inside the product Of growable in tile
    Crop,
    Coal,
    CropProduct;

    //Tree
    //Crop
    //Foraging
}