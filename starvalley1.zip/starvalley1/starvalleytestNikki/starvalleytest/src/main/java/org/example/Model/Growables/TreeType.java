package org.example.Model.Growables;

public enum TreeType {
    //boolean is foragingTree
}
