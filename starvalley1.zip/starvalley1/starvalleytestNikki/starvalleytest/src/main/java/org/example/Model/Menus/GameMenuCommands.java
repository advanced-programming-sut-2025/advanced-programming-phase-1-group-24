package org.example.Model.Menus;

public enum GameMenuCommands implements Commands {
    //inventory commands
    SHOW_INVENTORY("^\\s*inventory\\s+show\\s*$"),
    INVENTORY_TRASH("^\\s*inventory\\s+trash\\s+-i\\s+(?<itemName>.+?)(?:\\s+-n\\s+(?<number>\\d+))?$"),
    EQUIP_TOOL("^\\s*tools\\s+equip\\s+(?<toolName>.+)\\s*$"),
    SHOW_CURRENT_TOOL("^\\s*tools\\s+show\\s+current\\s*$"),
    SHOW_AVAILABLE_TOOLS("^\\s*tools\\s+show\\s+available\\s*$"),
    TOOL_UPGRADE("^\\s*tools\\s+upgrade\\s+(?<toolName>.+)\\s*$"),
    USE_TOOL("^\\s*tools\\s+use\\s+-d\\s+(?<direction>.+)\\s*$"),
    FISH("^\\s*fishing\\s+-p\\s+(?<fishingPole>.+)\\s*$"),
    CHEAT_ADD_ITEM("^\\s*cheat\\s+add\\s+item\\s+-n\\s+(?<itemName>.+)\\s+-c\\s+(?<count>\\d+)\\s*$");
}
