package org.example.Controller;

import Model.Menus.ProfileMenuCommands;
import Model.Result;

public class ProfileMenuController {

    ProfileMenuCommands command;

    public Result changeUsername(String newUsername) {
    }

    public Result changeNickname(String newNickname) {
    }

    public Result changeEmail(String newEmail) {
    }

    public Result changePassword(String newPassword, String oldPassword) {
    }

    public Result showUserInfo() {
    }
}

