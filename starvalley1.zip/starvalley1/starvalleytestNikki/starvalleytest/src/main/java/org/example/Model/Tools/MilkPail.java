package org.example.Model.Tools;

public class MilkPail extends Tool {
}
