package org.example.Controller;


import org.example.Model.Menus.MainMenuCommands;

public class MainMenuController {
    MainMenuCommands command;


}
