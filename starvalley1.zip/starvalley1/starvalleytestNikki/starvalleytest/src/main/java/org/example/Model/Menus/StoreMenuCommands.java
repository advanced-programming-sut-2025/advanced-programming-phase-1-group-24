package org.example.Model.Menus;

public enum StoreMenuCommands implements Commands{
}
