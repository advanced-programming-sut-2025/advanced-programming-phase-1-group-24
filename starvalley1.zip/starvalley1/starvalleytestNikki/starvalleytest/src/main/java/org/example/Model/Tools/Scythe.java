package org.example.Model.Tools;

import org.example.Model.Growables.Growable;
import org.example.Model.MapManagement.MapOfGame;
import org.example.Model.MapManagement.Tile;
import org.example.Model.Result;
import org.example.Model.Things.ToolMaterial;
import org.example.Model.User;

public class Scythe extends Tool{
    public Scythe() {
        this.material = ToolMaterial.Initial;
    }

    @Override
    public void upgrade(ToolMaterial material) {
        return;
    }

    public Result useScythe(int xDirection, int yDirection, Tile currentTile,
                            MapOfGame map, User currentPlayer) {
        int currentX = currentTile.getX();
        int currentY = currentTile.getY();

        int energy = 2;
        if (!currentPlayer.tryConsumeEnergy(energy)) {
            return new Result(false, "You don't have enough energy");
        }

        Tile nextTile = map.getMap()[currentY + yDirection][currentX + xDirection];
        Growable productOfGrowable = nextTile.getProductOfGrowable();
        if (productOfGrowable == null)
            return new Result(false, "Nothing to harvest here.");
        else {
            currentPlayer.getBackpack().addItem(productOfGrowable, 1);
            nextTile.setProductOfGrowable(null);
            return new Result(true, "Harvested " + productOfGrowable.getName());
        }
    }
}
