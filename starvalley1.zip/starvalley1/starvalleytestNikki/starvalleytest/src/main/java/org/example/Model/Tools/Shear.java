package org.example.Model.Tools;

public class Shear extends Tool{
}
