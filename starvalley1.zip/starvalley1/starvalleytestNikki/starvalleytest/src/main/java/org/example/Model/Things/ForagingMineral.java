package org.example.Model.Things;

public class ForagingMineral extends Item{
    ForagingMineralType type;
}
