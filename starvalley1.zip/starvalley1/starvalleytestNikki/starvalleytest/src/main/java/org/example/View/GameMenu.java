package org.example.View;

import org.example.Controller.GameMenuController;
import org.example.Model.Menus.GameMenuCommands;

import java.util.Scanner;
import java.util.regex.Matcher;

public class GameMenu implements AppMenu {
    GameMenuController controller = new GameMenuController();

    public void handleCommand(Scanner scanner) {
        String input = scanner.nextLine().trim();
        Matcher matcher;

        /// //////////////////////////////////////////////////////////////////

        else if ((matcher = GameMenuCommands.SHOW_INVENTORY.getMatcher(input)) != null) {
            System.out.println(controller.showInventory());
        } else if ((matcher = GameMenuCommands.INVENTORY_TRASH.getMatcher(input)) != null) {
            String itemName = matcher.group("itemName");
            String countString = matcher.group("number");
            int count;
            if (countString == null) count = 1000;
            else count = Integer.parseInt(countString);
            System.out.println(controller.trashInventory(itemName, count));
        } else if ((matcher = GameMenuCommands.EQUIP_TOOL.getMatcher(input)) != null) {
            String toolName = matcher.group("toolName");
            System.out.println(controller.equipTool(toolName));
        } else if ((matcher = GameMenuCommands.SHOW_CURRENT_TOOL.getMatcher(input)) != null) {
            System.out.println(controller.showCurrentTool());
        } else if ((matcher = GameMenuCommands.SHOW_AVAILABLE_TOOLS.getMatcher(input)) != null) {
            System.out.println(controller.showAllTools());
        } else if ((matcher = GameMenuCommands.TOOL_UPGRADE.getMatcher(input)) != null) {
            //COMPLETE THIS AFTER MAKING SHOP
        } else if ((matcher = GameMenuCommands.USE_TOOL.getMatcher(input)) != null) {
            //COMPLETE THIS AFTER COMPLETEING TOOLS
        } else if ((matcher = GameMenuCommands.FISH.getMatcher(input)) != null) {
            String fishingPole = matcher.group("fishingPole");
            System.out.println(controller.fish(fishingPole));
        } else if ((matcher = GameMenuCommands.CHEAT_ADD_ITEM.getMatcher(input)) != null) {
            String itemName = matcher.group("itemName");
            int count = Integer.parseInt(matcher.group("count"));
            System.out.println(controller.cheatAddItem(itemName, count));
            //COMPLETE THIS AFTER WRITING LIST OF ALL ITEMS
        }




        /// ////////////////////////////////////////////////////////////////////
    }

}
