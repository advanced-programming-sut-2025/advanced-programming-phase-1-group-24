package org.example.Model.Reccepies;

public enum randomStuffType {
    Pumpkin,
    WheatFlower,
    Sugar,
    Cheese,
    Rice,
    Fiber,
    Coffee,
    Oil,
    Wood,
}
