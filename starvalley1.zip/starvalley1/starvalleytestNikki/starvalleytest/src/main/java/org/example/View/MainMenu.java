package org.example.View;

import Controller.MainMenuController;

import java.util.Scanner;

public class MainMenu implements AppMenu{
    MainMenuController controller = new MainMenuController();


    public void check(Scanner scanner) {}
}
