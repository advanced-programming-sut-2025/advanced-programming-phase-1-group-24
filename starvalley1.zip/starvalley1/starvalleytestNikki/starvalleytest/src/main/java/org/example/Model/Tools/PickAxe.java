package org.example.Model.Tools;

import org.example.Model.Things.ToolMaterial;

public class PickAxe extends Tool{
    public PickAxe() {
        this.material = ToolMaterial.Initial;
    }
}
