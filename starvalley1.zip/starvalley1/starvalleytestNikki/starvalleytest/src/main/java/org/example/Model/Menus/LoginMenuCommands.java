package org.example.Model.Menus;

public enum LoginMenuCommands implements Commands {
}
