package org.example.Model.Reccepies;

import org.example.Model.Things.Item;

public class randomStuff extends Item {
    randomStuffType type;

    public randomStuff(randomStuffType type) {
        this.type = type;
    }
}
