package org.example.Model.Things;

public class Food extends Item{
    FoodType type;
    int energy;

    public Food(FoodType type) {
        this.type = type;
        this.energy = type.getRecipe().getEnergy();
        this.price =
    }
}
