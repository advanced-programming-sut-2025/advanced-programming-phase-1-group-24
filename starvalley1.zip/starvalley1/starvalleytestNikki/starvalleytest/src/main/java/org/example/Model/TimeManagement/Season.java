package org.example.Model.TimeManagement;

import java.util.ArrayList;

public enum Season {
    SPRING(new ArrayList<>()),
    SUMMER(new ArrayList<>()),
    AUTUMN(new ArrayList<>()),
    WINTER(new ArrayList<>());

    ArrayList<WeatherType> weatherTypes;
    //ArrayList source (mixed seeds)
    //product class
    Season(ArrayList<WeatherType> weatherTypes) {
        this.weatherTypes = weatherTypes;
    }

    public ArrayList<WeatherType> getWeatherTypes() {
        return weatherTypes;
    }
}
