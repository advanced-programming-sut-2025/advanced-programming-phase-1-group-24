package org.example.Controller;

public class HouseMenuController {
}
