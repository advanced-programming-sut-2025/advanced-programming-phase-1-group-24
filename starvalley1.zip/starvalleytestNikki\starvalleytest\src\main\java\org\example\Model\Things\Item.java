package org.example.Model.Things;

public class Item {
    ItemType type;
    //foraging minerals
    //
    //animal products 
}
