package org.example.Controller;

public class TradeMenuController {
}
