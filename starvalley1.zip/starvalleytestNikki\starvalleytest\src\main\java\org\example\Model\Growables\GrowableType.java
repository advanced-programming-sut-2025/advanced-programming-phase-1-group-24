package org.example.Model.Growables;

public enum GrowableType {
    Tree {
        TreeType type;
    },
    Plant{
        CropType type;
    };
 
    //Tree
    //Crop
    //Foraging 
}
