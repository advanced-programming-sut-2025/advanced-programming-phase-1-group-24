package org.example.View;

import Controller.StoreMenuController;

import java.util.Scanner;

public class StoreMenu implements AppMenu{
    StoreMenuController controller = new StoreMenuController();
    public void check(Scanner scanner) {}
}
