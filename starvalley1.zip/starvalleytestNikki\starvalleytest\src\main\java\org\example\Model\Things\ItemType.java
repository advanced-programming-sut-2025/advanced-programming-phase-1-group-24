package org.example.Model.Things;

public enum ItemType {
}
