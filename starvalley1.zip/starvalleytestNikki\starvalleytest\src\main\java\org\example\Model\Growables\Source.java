package org.example.Model.Growables;

public enum Source {
JazzSeeds,
CarrotSeeds,
CauliflowerSeeds,
CoffeeBean,
GarlicSeeds,
Bean Starter,
Kale Seeds,
Parsnip Seeds,
Potato Seeds,
Rhubarb Seeds,
Strawberry Seeds,
Tulip Bulb,
Rice Shoot,
Blueberry Seeds,
Corn Seeds,
Hops Starter,
Pepper Seeds,
Melon Seeds,
Poppy Seeds,
Radish Seeds,
Red Cabbage Seeds,
Starfruit Seeds,
Spangle Seeds,
Summer Squash Seeds,
Sunflower Seeds,
Tomato Seeds,
Wheat Seeds,
Amaranth Seeds,
Artichoke Seeds,
Beet Seeds,
Bok Choy Seeds,
Broccoli Seeds,
Cranberry Seeds,
Eggplant Seeds,
Fairy Seeds,
Grape Starter,
Pumpkin Seeds,
Yam Seeds,
Rare Seed,
Powdermelon Seeds,
Ancient Seeds;
    



    //boolea isForaging seed
    Season Season;
}
