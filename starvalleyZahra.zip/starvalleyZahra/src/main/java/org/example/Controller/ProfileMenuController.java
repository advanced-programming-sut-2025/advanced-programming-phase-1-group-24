package org.example.Controller;


import org.example.Model.Menus.ProfileMenuCommands;
import org.example.Model.Result;

public class ProfileMenuController implements MenuController {

    ProfileMenuCommands command;

//    public Result changeUsername(String newUsername) {
//    }
//
//    public Result changeNickname(String newNickname) {
//    }
//
//    public Result changeEmail(String newEmail) {
//    }
//
//    public Result changePassword(String newPassword, String oldPassword) {
//    }
//
//    public Result showUserInfo() {
//    }
}

