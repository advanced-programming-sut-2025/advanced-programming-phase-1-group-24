package org.example.Controller;


import org.example.Model.Menus.LoginMenuCommands;
import org.example.Model.Result;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginMenuController implements MenuController {

    LoginMenuCommands command;

    // Simulating a database with a HashMap for this example
    private static Map<String, String> userDatabase = new HashMap<>();

    // Method to handle the registration
    public Result register(Matcher matcher) {
        // Extracting user input from matcher (e.g., username, password, etc.)
        String username = matcher.group("username");
        String password = matcher.group("password");
        String passwordConfirm = matcher.group("password_confirm");
        String email = matcher.group("email");
        String nickname = matcher.group("nickname");
        String gender = matcher.group("gender");

        // Check username validity
        if (!isValidUsername(username)) {
            return new Result("Error: Invalid username. It must only contain alphanumeric characters and dashes.");
        }

        // Check if the username already exists
        if (userDatabase.containsKey(username)) {
            username = generateUniqueUsername(username); // Modify the username to make it unique
        }

        // Check email validity
        if (!isValidEmail(email)) {
            return new Result("Error: Invalid email format.");
        }

        // Validate password
        if (!isValidPassword(password)) {
            return new Result("Error: Invalid password. It must be at least 8 characters long, contain upper and lowercase letters, numbers, and special characters.");
        }

        // Check if password matches confirmation
        if (!password.equals(passwordConfirm)) {
            return new Result("Error: Password and confirmation do not match.");
        }

        // Hash the password using SHA-256 before saving (security measure)
        String hashedPassword = hashPassword(password);

        // Save user data in database
        userDatabase.put(username, hashedPassword);

        // Ask for a security question after successful registration
        return new Result("Registration successful! Please pick a security question to continue.");
    }

    // Helper method to check if the username is valid
    private boolean isValidUsername(String username) {
        return username != null && username.matches("[a-zA-Z0-9-]+");
    }

    // Helper method to generate a unique username if the original one is taken
    private String generateUniqueUsername(String username) {
        Random random = new Random();
        String newUsername;
        do {
            newUsername = username + "-" + random.nextInt(1000);
        } while (userDatabase.containsKey(newUsername));
        return newUsername;
    }

    // Helper method to check if the email is valid
    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    // Helper method to validate password strength
    private boolean isValidPassword(String password) {
        if (password.length() < 8) return false;

        boolean hasUpper = false;
        boolean hasLower = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isLowerCase(c)) hasLower = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else if ("!#$%^&*()=+{}[]|/\\:;,'\"<>,.?".contains(String.valueOf(c))) hasSpecial = true;
        }

        return hasUpper && hasLower && hasDigit && hasSpecial;
    }

    // Helper method to hash the password using SHA-256
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Result class to represent the outcome of the registration process
    public static class Result {
        private String message;

        public Result(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }

//    public Result createUser(String username, String nickname, String password, String confirmPassword, String email, String gender){}
//    public Result pickQuestion(int question, String answer, String confirmAnswer){}
//    public Result login(String username, String password, boolean stayLoggedIn){}
//    public Result forgetPassword(String username, String answer){}

}
