package org.example.Model.Menus;

import java.util.regex.Matcher;

public enum LoginMenuCommands implements Commands {
    REGISTER("^register\\s+-u\\s+((?<username>.+)\\s+-p\\s+(?<password>.+)\\s+(?<password_confirm>.+)" +
            "\\s+-n\\s+(?<nickname>.+)\\s+-e\\s+(?<email>.+)\\s+-g\\s+(?<gender>.+)$"),
    MENU_ENTER(Commands.MENU_ENTER),
    SHOW_MENU(Commands.SHOW_MENU),
    EXIT(Commands.EXIT);

    private final String regex;

    LoginMenuCommands(String regex) {
        this.regex = regex;
    }

    @Override
    public String getRegex() {
        return regex;
    }

}
