package org.example.Model.Animals;


import org.example.Model.MapManagement.Tile;

public class Animal {
    AnimalType animalType;
    Tile currentTile;

    public AnimalType getAnimalType() {
        return animalType;
    }
}
