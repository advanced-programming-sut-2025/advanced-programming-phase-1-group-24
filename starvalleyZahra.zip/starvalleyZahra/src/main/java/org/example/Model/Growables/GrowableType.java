package org.example.Model.Growables;

public enum GrowableType {
    Tree {
        TreeType type;
    },
    Plant{
        PlantType type;
    };
}
