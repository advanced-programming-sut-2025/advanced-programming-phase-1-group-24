package org.example.Model.MapManagement;


import org.example.Model.Growables.Growable;
import org.example.Model.Things.Item;

public class Tile {
    int x;
    int y;
    TileType type;
    boolean isWalkable;
    Item containedItem;
    Growable containedGrowable;

    public void changeTile(){}

}
