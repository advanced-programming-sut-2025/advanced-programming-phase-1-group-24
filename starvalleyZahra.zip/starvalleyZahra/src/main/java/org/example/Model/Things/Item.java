package org.example.Model.Things;

public class Item {
    ItemType type;
}
