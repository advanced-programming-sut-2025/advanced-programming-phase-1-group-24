package org.example.Model.Things;

public enum Material {
    Initial,
    Iron,
    Gold,
    Copper,
    Iridium;
}
