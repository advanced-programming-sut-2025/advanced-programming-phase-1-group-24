package org.example.Model.Growables;

public enum PlantType {
}
