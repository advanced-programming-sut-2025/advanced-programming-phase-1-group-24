package org.example.Model.Menus;

public enum TradeMenuController {
}
