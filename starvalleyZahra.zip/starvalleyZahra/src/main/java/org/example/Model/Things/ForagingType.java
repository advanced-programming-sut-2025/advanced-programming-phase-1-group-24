package org.example.Model.Things;

public enum ForagingType {
}
