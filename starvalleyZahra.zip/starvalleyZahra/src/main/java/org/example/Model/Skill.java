package org.example.Model;

public enum Skill {
    fishingSkill,
    farmingSkill,
    miningSkill,
    foragingSkill;
}
