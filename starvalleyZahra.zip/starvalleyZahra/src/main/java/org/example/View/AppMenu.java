package org.example.View;

import java.util.Scanner;

public interface AppMenu {
    public void handleCommand(Scanner scanner);
}
