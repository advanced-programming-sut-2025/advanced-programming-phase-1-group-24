package org.example.View;


import org.example.Controller.TradeMenuController;

import java.util.Scanner;

public class TradeMenu implements AppMenu {
    TradeMenuController controller = new TradeMenuController();
    public void handleCommand(Scanner scanner) {}
}
