package org.example.View;


import org.example.Controller.HouseMenuController;

import java.util.Scanner;

public class HouseMenu implements AppMenu {
    HouseMenuController controller = new HouseMenuController();
    public void handleCommand(Scanner scanner) {}
}
