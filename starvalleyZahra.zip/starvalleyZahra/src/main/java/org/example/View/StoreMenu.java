package org.example.View;


import org.example.Controller.StoreMenuController;

import java.util.Scanner;

public class StoreMenu implements AppMenu{
    StoreMenuController controller = new StoreMenuController();
    public void handleCommand(Scanner scanner) {}
}
